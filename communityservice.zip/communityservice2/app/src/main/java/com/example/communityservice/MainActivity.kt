package com.example.communityservice


import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.tooling.preview.Preview
import com.example.communityservice.data.model.Issue
import com.example.communityservice.viewmodel.StaffDashboardViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: StaffDashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface {
                    val uiState by viewModel.uiState.collectAsState()
                    var showAssignPageFirst by remember { mutableStateOf(true) }
                    val activeIssueToAssign = remember {
                        Issue(
                            issueID = "ISS-1046",
                            category = "Electrical Grid",
                            description = "Power transformer sparking and streetlight failure at Park Ave",
                            priority = "High",
                            status = "Reported"
                        )
                    }

                    if (showAssignPageFirst) {
                        AssignIssueScreen(
                            issue = activeIssueToAssign,
                            onBackClick = { showAssignPageFirst = false },
                            onAssignClick = { assignedTo, priority, notes ->
                                viewModel.saveAssignment(
                                    issueId = activeIssueToAssign.issueID,
                                    assignedTo = assignedTo,
                                    newPriority = priority,
                                    internalNotes = notes
                                )

                                Toast.makeText(
                                    this@MainActivity,
                                    "Electricity issue assigned to $assignedTo!",
                                    Toast.LENGTH_SHORT
                                ).show()

                                showAssignPageFirst = false
                            }
                        )
                    } else {
                        StaffDashboardScreen(
                            issues = uiState.filteredIssues,
                            reportedCount = uiState.reportedCount,
                            inProgressCount = uiState.inProgressCount,
                            assignedCount = uiState.assignedCount,
                            resolvedCount = uiState.resolvedCount,
                            selectedFilter = uiState.selectedFilter,
                            onFilterSelected = { filter ->
                                viewModel.setFilter(filter)
                            },
                            onIssueClick = {
                                showAssignPageFirst = true
                            }
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun StaffDashboardScreenPreview() {
    val sampleIssues = listOf(
        Issue(
            issueID = "1",
            category = "Water Supply",
            description = "Main pipe burst near 5th avenue causing road flooding.",
            priority = "High",
            status = "Reported"
        ),
        Issue(
            issueID = "2",
            category = "Pothole",
            description = "Deep crater on Main Street near the central bank.",
            priority = "Medium",
            status = "In Progress"
        ),
        Issue(
            issueID = "3",
            category = "Street Light",
            description = "Light post #42 out of order for 3 days.",
            priority = "Low",
            status = "Resolved"
        )
    )

    StaffDashboardScreen(
        issues = sampleIssues,
        reportedCount = 12,
        inProgressCount = 4,
        assignedCount = 8,
        resolvedCount = 25,
        selectedFilter = "All",
        onFilterSelected = {},
        onIssueClick = {}
    )
}