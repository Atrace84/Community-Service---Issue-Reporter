package com.example.communityservice.data.repository

import com.example.communityservice.data.model.Issue
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class StaffRepository {

    private val seedIssues = listOf(
        Issue("ISS-1047", "Water & Sanitation", "Water leak outside 42 Main Road", "High", "Reported", ""),
        Issue("ISS-1046", "Electrical Grid", "Broken streetlight at Park Ave", "High", "In Progress", "Electrical Response Alpha"),
        Issue("ISS-1045", "Waste Management", "Overflowing bin at 15 Market St", "Medium", "Assigned", "Sanitation Crew 3"),
        Issue("ISS-1044", "Roads & Infrastructure", "Pothole on 3rd Street", "Low", "Reported", "")
    )

    private val _issuesFlow = MutableStateFlow<List<Issue>>(seedIssues)

    fun getRealtimeIssues(): Flow<List<Issue>> = _issuesFlow.asStateFlow()

    fun addIssue(issue: Issue) {
        _issuesFlow.update { currentList ->
            listOf(issue) + currentList
        }
    }

    fun assignIssue(
        issueId: String,
        assignedTo: String,
        newPriority: String,
        notes: String
    ) {
        _issuesFlow.update { currentList ->
            currentList.map { issue ->
                if (issue.issueID == issueId) {
                    val updatedDesc = if (notes.isNotBlank()) "${issue.description}\nNote: $notes" else issue.description
                    issue.copy(
                        priority = newPriority,
                        status = "Assigned",
                        assignedTo = assignedTo,
                        description = updatedDesc
                    )
                } else {
                    issue
                }
            }
        }
    }
}