package com.example.communityservice

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.communityservice.data.model.Issue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignIssueScreen(
    issue: Issue,
    onBackClick: () -> Unit,
    onAssignClick: (assignedTo: String, priority: String, notes: String) -> Unit
) {

    val teamOptions = when {
        issue.category.contains("Electric", ignoreCase = true) ||
                issue.category.contains("Power", ignoreCase = true) ||
                issue.category.contains("Grid", ignoreCase = true) -> listOf(
            "Electrical Repair Team 1",
            "Electrical Grid Team 2",
            "Power Line Crew Alpha"
        )

        issue.category.contains("Water", ignoreCase = true) ||
                issue.category.contains("Sanitation", ignoreCase = true) -> listOf(
            "Water Repair Team 4",
            "Plumbing & Sanitation Crew",
            "Pipe Maintenance Team B"
        )

        issue.category.contains("Waste", ignoreCase = true) ||
                issue.category.contains("Garbage", ignoreCase = true) -> listOf(
            "Sanitation Crew 3",
            "Waste Management Unit 1"
        )

        else -> listOf(
            "General Municipal Maintenance",
            "Public Works Team 1",
            "Infrastructure Response Unit"
        )
    }
    val priorityOptions = listOf("Low", "Medium", "High", "Urgent")

    var selectedTeam by remember(issue) { mutableStateOf(teamOptions.first()) }
    var selectedPriority by remember(issue) { mutableStateOf(issue.priority.ifBlank { "High" }) }
    var notesText by remember { mutableStateOf("") }

    var expandedTeamDropdown by remember { mutableStateOf(false) }
    var expandedPriorityDropdown by remember { mutableStateOf(false) }


    val (iconVector, iconBgColor, iconTintColor) = when {
        issue.category.contains("Electric", ignoreCase = true) ||
                issue.category.contains("Power", ignoreCase = true) ||
                issue.category.contains("Grid", ignoreCase = true) -> Triple(Icons.Default.Bolt, Color(0xFFFEF3C7), Color(0xFFD97706)) // Amber / Gold Electricity Badge

        issue.category.contains("Water", ignoreCase = true) ||
                issue.category.contains("Sanitation", ignoreCase = true) -> Triple(Icons.Default.WaterDrop, Color(0xFFDBEAFE), Color(0xFF2563EB)) // Royal Blue Water Badge

        issue.category.contains("Waste", ignoreCase = true) ||
                issue.category.contains("Garbage", ignoreCase = true) -> Triple(Icons.Default.DeleteSweep, Color(0xFFDCFCE7), Color(0xFF16A34A)) // Emerald Green Waste Badge

        else -> Triple(Icons.Default.Handyman, Color(0xFFF1F5F9), Color(0xFF475569))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(issue.issueID, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFF0F172A))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(iconBgColor, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = iconVector,
                                    contentDescription = null,
                                    tint = iconTintColor,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = issue.category,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "Status: ${issue.status}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                text = selectedPriority,
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = issue.description,
                        fontSize = 14.sp,
                        color = Color(0xFF334155),
                        lineHeight = 20.sp
                    )
                }
            }


            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Assignment Details",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF0F172A)
                    )

                    Column {
                        Text(
                            text = "Assign To *",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                                    .clickable { expandedTeamDropdown = true }
                                    .padding(horizontal = 14.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedTeam, color = Color(0xFF0F172A), fontSize = 14.sp)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF64748B))
                            }
                            DropdownMenu(
                                expanded = expandedTeamDropdown,
                                onDismissRequest = { expandedTeamDropdown = false }
                            ) {
                                teamOptions.forEach { team ->
                                    DropdownMenuItem(
                                        text = { Text(team) },
                                        onClick = {
                                            selectedTeam = team
                                            expandedTeamDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Column {
                        Text(
                            text = "Priority Level",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                                    .clickable { expandedPriorityDropdown = true }
                                    .padding(horizontal = 14.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedPriority, color = Color(0xFF0F172A), fontSize = 14.sp)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF64748B))
                            }
                            DropdownMenu(
                                expanded = expandedPriorityDropdown,
                                onDismissRequest = { expandedPriorityDropdown = false }
                            ) {
                                priorityOptions.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text(p) },
                                        onClick = {
                                            selectedPriority = p
                                            expandedPriorityDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Column {
                        Text(
                            text = "Notes (Internal)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = notesText,
                            onValueChange = { if (it.length <= 250) notesText = it },
                            placeholder = { Text("Enter internal assignment notes...", color = Color(0xFF94A3B8), fontSize = 14.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF2563EB),
                                unfocusedBorderColor = Color(0xFFE2E8F0),
                                focusedContainerColor = Color(0xFFF8FAFC),
                                unfocusedContainerColor = Color(0xFFF8FAFC)
                            )
                        )
                        Text(
                            text = "${notesText.length}/250",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.align(Alignment.End).padding(top = 4.dp)
                        )
                    }
                }
            }

            Button(
                onClick = { onAssignClick(selectedTeam, selectedPriority, notesText) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
            ) {
                Text(
                    text = "Assign Issue",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}