package com.example.communityservice.viewmodel

import androidx.lifecycle.ViewModel
import com.example.communityservice.data.model.Issue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class StaffDashboardUiState(
    val issues: List<Issue> = emptyList(),
    val filteredIssues: List<Issue> = emptyList(),
    val selectedFilter: String = "All",
    val reportedCount: Int = 0,
    val inProgressCount: Int = 0,
    val assignedCount: Int = 0,
    val resolvedCount: Int = 0
)

class StaffDashboardViewModel : ViewModel() {


    private val seedIssues = mutableListOf(
        Issue("ISS-1047", "Water & Sanitation", "Water leak outside 42 Main Road", "High", "Reported", ""),
        Issue("ISS-1046", "Electrical Grid", "Broken streetlight at Park Ave", "High", "In Progress", "Electrical Response Alpha"),
        Issue("ISS-1045", "Waste Management", "Overflowing bin at 15 Market St", "Medium", "Assigned", "Sanitation Crew 3"),
        Issue("ISS-1044", "Roads & Infrastructure", "Pothole on 3rd Street", "Low", "Reported", "")
    )

    private val _uiState = MutableStateFlow(StaffDashboardUiState())
    val uiState: StateFlow<StaffDashboardUiState> = _uiState.asStateFlow()

    init {
        recalculateState(seedIssues)
    }

    fun saveAssignment(
        issueId: String,
        assignedTo: String,
        newPriority: String,
        internalNotes: String
    ) {
        val currentList = _uiState.value.issues.toMutableList()
        val index = currentList.indexOfFirst { it.issueID == issueId }

        if (index != -1) {
            val existingIssue = currentList[index]
            val updatedDescription = if (internalNotes.isNotBlank()) {
                "${existingIssue.description}\nNote: $internalNotes"
            } else {
                existingIssue.description
            }


            currentList[index] = existingIssue.copy(
                priority = newPriority,
                status = "Assigned",
                assignedTo = assignedTo,
                description = updatedDescription
            )
        } else {

            currentList.add(
                0,
                Issue(
                    issueID = issueId,
                    category = "Municipal Assignment",
                    description = if (internalNotes.isNotBlank()) internalNotes else "Assigned work request",
                    priority = newPriority,
                    status = "Assigned",
                    assignedTo = assignedTo
                )
            )
        }

        recalculateState(currentList)
    }

    fun setFilter(filter: String) {
        _uiState.update { currentState ->
            currentState.copy(
                selectedFilter = filter,
                filteredIssues = filterList(currentState.issues, filter)
            )
        }
    }

    private fun recalculateState(issueList: List<Issue>) {
        val reported = issueList.count { it.status.equals("Reported", ignoreCase = true) }
        val inProgress = issueList.count { it.status.equals("In Progress", ignoreCase = true) }
        val assigned = issueList.count { it.status.equals("Assigned", ignoreCase = true) }
        val resolved = issueList.count { it.status.equals("Resolved", ignoreCase = true) }

        _uiState.update { currentState ->
            currentState.copy(
                issues = issueList,
                filteredIssues = filterList(issueList, currentState.selectedFilter),
                reportedCount = reported,
                inProgressCount = inProgress,
                assignedCount = assigned,
                resolvedCount = resolved
            )
        }
    }

    private fun filterList(list: List<Issue>, filter: String): List<Issue> {
        return if (filter == "All") {
            list
        } else {
            list.filter { it.status.equals(filter, ignoreCase = true) }
        }
    }
}