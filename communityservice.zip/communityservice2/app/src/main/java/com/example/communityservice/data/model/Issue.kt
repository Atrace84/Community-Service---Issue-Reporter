package com.example.communityservice.data.model

data class Issue(
    val issueID: String,
    val category: String,
    val description: String,
    val priority: String,
    val status: String,
    val assignedTo: String = "" // Added field
)